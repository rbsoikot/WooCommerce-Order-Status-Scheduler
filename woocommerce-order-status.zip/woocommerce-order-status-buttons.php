<?php
/*
Plugin Name: WooCommerce Order Status Buttons
Description: Adds quick status change buttons with optional countdown timer to order edit pages in admin
Version: 1.4
Author: Your Name
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Add custom field for timer in order admin
add_action('woocommerce_admin_order_data_after_order_details', 'add_timer_field_to_order');
function add_timer_field_to_order($order) {
    ?>
    <p class="form-field form-field-wide">
        <label for="order_timer_minutes"><?php _e('Set Auto On-Hold Timer (minutes):', 'woocommerce'); ?></label>
        <input type="number" min="0" step="1" name="order_timer_minutes" id="order_timer_minutes" 
               value="<?php echo esc_attr(get_post_meta($order->get_id(), '_order_timer_minutes', true)); ?>" 
               style="width: 60px;" />
        <span class="description"><?php _e('Set minutes for auto on-hold status (0 to disable)', 'woocommerce'); ?></span>
    </p>
    <?php
}

// Save timer field
add_action('woocommerce_process_shop_order_meta', 'save_timer_field');
function save_timer_field($order_id) {
    if (isset($_POST['order_timer_minutes'])) {
        $minutes = intval($_POST['order_timer_minutes']);
        update_post_meta($order_id, '_order_timer_minutes', $minutes);
        
        if ($minutes > 0) {
            $expire_time = time() + ($minutes * 60);
            update_post_meta($order_id, '_order_timer_expire', $expire_time);
        } else {
            delete_post_meta($order_id, '_order_timer_expire');
        }
    }
}

// Add buttons to order actions meta box
add_action('woocommerce_order_actions_end', 'add_custom_order_status_buttons');
function add_custom_order_status_buttons($order_id) {
    $order = wc_get_order($order_id);
    $current_status = $order->get_status();
    ?>
    <div class="custom-order-actions">
    <?php
    if ($current_status !== 'on-hold') {
        $timer_minutes = get_post_meta($order_id, '_order_timer_minutes', true);
        $expire_time = get_post_meta($order_id, '_order_timer_expire', true);
        
        ?>
        <div class="timer-button-group">
            <?php if ($timer_minutes && $expire_time && $expire_time > time()) : ?>
                <span id="countdown-timer-<?php echo esc_attr($order_id); ?>" 
                      class="countdown-timer" 
                      data-order-id="<?php echo esc_attr($order_id); ?>" 
                      data-expire="<?php echo esc_attr($expire_time); ?>">
                    <?php
                    $remaining = $expire_time - time();
                    $minutes = floor($remaining / 60);
                    $seconds = $remaining % 60;
                    echo sprintf('%02d:%02d', $minutes, $seconds);
                    ?>
                </span>
            <?php endif; ?>
            <button type="button" class="button change-status-on-hold" data-order-id="<?php echo esc_attr($order_id); ?>">
                <?php _e('Change to On Hold', 'woocommerce'); ?>
            </button>
        </div>
        <?php
    }
    
    if ($current_status !== 'completed') {
        ?>
        <button type="button" class="button change-status-completed" data-order-id="<?php echo esc_attr($order_id); ?>">
            <?php _e('Change to Completed', 'woocommerce'); ?>
        </button>
        <?php
    }
    ?>
    </div>
    <?php
}

// Add JavaScript for button functionality and timer
add_action('admin_footer', 'custom_order_status_buttons_script');
function custom_order_status_buttons_script() {
    $screen = get_current_screen();
    if ($screen->id !== 'shop_order') return;
    ?>
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('.change-status-on-hold').on('click', function(e) {
            e.preventDefault();
            var orderId = $(this).data('order-id');
            changeOrderStatus(orderId, 'on-hold');
        });

        $('.change-status-completed').on('click', function(e) {
            e.preventDefault();
            var orderId = $(this).data('order-id');
            changeOrderStatus(orderId, 'completed');
        });

        function startTimer() {
            $('.countdown-timer').each(function() {
                var $timer = $(this);
                var orderId = $timer.data('order-id');
                var expireTime = parseInt($timer.data('expire')) * 1000;
                
                function updateTimer() {
                    var now = new Date().getTime();
                    var distance = expireTime - now;

                    if (distance <= 0) {
                        changeOrderStatus(orderId, 'on-hold');
                        $timer.text('00:00');
                        return;
                    }

                    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
                    
                    $timer.text(
                        (minutes < 10 ? '0' + minutes : minutes) + ':' + 
                        (seconds < 10 ? '0' + seconds : seconds)
                    );
                }

                updateTimer();
                setInterval(updateTimer, 1000);
            });
        }

        startTimer();

        function changeOrderStatus(orderId, status) {
            $('#post').block({
                message: null,
                overlayCSS: {
                    background: '#000',
                    opacity: 0.6
                }
            });

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'change_order_status_custom',
                    order_id: orderId,
                    status: status,
                    security: '<?php echo wp_create_nonce("change_order_status"); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        window.location.reload();
                    } else {
                        alert('Error changing order status: ' + (response.data.message || 'Unknown error'));
                    }
                },
                error: function(xhr, status, error) {
                    alert('Error: Could not connect to server - ' + error);
                },
                complete: function() {
                    $('#post').unblock();
                }
            });
        }
    });
    </script>
    <?php
}

// Handle the AJAX request to change order status
add_action('wp_ajax_change_order_status_custom', 'handle_change_order_status');
function handle_change_order_status() {
    check_ajax_referer('change_order_status', 'security');

    if (!current_user_can('edit_shop_orders')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }

    $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
    $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';

    if (!$order_id || !$status) {
        wp_send_json_error(array('message' => 'Invalid parameters'));
        return;
    }

    $order = wc_get_order($order_id);
    if (!$order) {
        wp_send_json_error(array('message' => 'Order not found'));
        return;
    }

    try {
        if ($status === 'completed' && !$order->is_paid()) {
            $order->payment_complete();
        }
        
        $order->update_status($status);
        if ($status === 'on-hold') {
            delete_post_meta($order_id, '_order_timer_minutes');
            delete_post_meta($order_id, '_order_timer_expire');
        }
        wp_send_json_success();
    } catch (Exception $e) {
        wp_send_json_error(array('message' => $e->getMessage()));
    }
}

// Add styling
add_action('admin_head', 'custom_order_status_buttons_styles');
function custom_order_status_buttons_styles() {
    $screen = get_current_screen();
    if ($screen->id !== 'shop_order') return;
    
    echo '<style>
        .custom-order-actions {
            margin-top: 10px;
            padding: 5px 0;
        }
        .timer-button-group {
            display: inline-flex;
            align-items: center;
            margin: 5px 5px 0 0;
            vertical-align: middle;
        }
        .countdown-timer {
            display: inline-block;
            background: #f7e1a1;
            padding: 4px 8px;
            border-radius: 3px;
            font-weight: bold;
            margin-right: 5px;
            min-width: 40px;
            text-align: center;
        }
        .change-status-on-hold,
        .change-status-completed {
            margin: 0 5px 0 0 !important;
            padding: 4px 8px;
        }
        .change-status-on-hold {
            background-color: #f7e1a1;
            border-color: #f7e1a1;
            color: #333;
        }
        .change-status-on-hold:hover {
            background-color: #f5d78e;
            border-color: #f5d78e;
        }
        .change-status-completed {
            background-color: #c6e1c6;
            border-color: #c6e1c6;
            color: #333;
        }
        .change-status-completed:hover {
            background-color: #b3d9b3;
            border-color: #b3d9b3;
        }
    </style>';
}